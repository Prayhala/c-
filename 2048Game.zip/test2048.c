#include"2048.h"
int main()
{
	int input = 0;
	do
	{
		menu();
		scanf_s("%d", &input);
		char kb = 0;
		kb = getchar();
		switch (input)
		{
		case 1:
			game2048();
			break;
		case 0:
			printf("�˳���Ϸ\n");
			break;
		default:
			printf("����������\n");
			break;
		}
	} while (input);
	return 0;
}
#pragma once
#include"2048.h"
//�˵�����
void menu()
{
	printf("****************************\n");
	printf("**  ��1��ʼ��Ϸ  ***********\n");
	printf("**  ��0������Ϸ  ***********\n");
	printf("****************************\n");
}

//��ӡ��
void PrintBoard(int arr[4][4])
{
	printf("+-----+-----+-----+-----+\n");
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			printf("|");
			if (arr[i][j] == 0)
				printf("     ");
			else
				printf("%4d ", arr[i][j]);
		}
		printf("|");
		printf("\n");
		printf("+-----+-----+-----+-----+\n");
	}
}

//������ɳ�ʼ��λ��
void get_num(int arr[4][4])
{
	srand((unsigned int)time(NULL));
	int x = rand() % 4;
	int y = rand() % 4;
	arr[x][y] = 2;
	while (arr[x][y] == 2)
	{
		x = rand() % 4;
		y = rand() % 4;
	}
	arr[x][y] = 2;
}

//ʵ���ƶ�
void Move(int arr[4][4])
{
	char input = 0;
	change:
	scanf_s("%c", &input,1);
	switch (input)
	{
	//���ƶ�
	case 'w':
		up(arr);
		break;
	//���ƶ�
	case 's':
		down(arr);
		break;
	//���ƶ�
	case 'a':
		left(arr);
		break;
	//���ƶ�
	case 'd':
	    right(arr);
		break;
	default:
		goto change;
		break;
	}
}

//���ƶ�
void up(int arr[4][4])
{
	int i = 0, j = 0, m = 0, n = 0;
	for (i = 0; i < COL; i++)
	{
		m = n = 0;
		//�ƶ�
		while (m < ROW - 1 && n < ROW - 1)
		{
			if (arr[m][i] == 0)
			{
				for (j = m; j < ROW - 1; j++)
					arr[j][i] = arr[j + 1][i];
				arr[j][i] = 0;
				n++;
			}
			else
				m++;
		}
		// �ϲ�
		for (j = 0; j < ROW-1; j++)
		{
			if (arr[j][i] == arr[j + 1][i] && arr[j][i] != 0)
			{
				arr[j][i] *= 2;
				arr[j + 1][i] = 0;
			}
		}
		//���ƶ�
		m = n = 0;
		while (m < ROW - 1 && n < ROW - 1)
		{
			if (arr[m][i] == 0)
			{
				for (j = m; j < ROW - 1; j++)
					arr[j][i] = arr[j + 1][i];
				arr[j][i] = 0;
				n++;
			}
			else
				m++;
		}
	}
}

//���ƶ�
void down(int arr[4][4])
{
	int i = 0, j = 0, m = 0, n = 0;
	for (i = 0; i < COL ; i++)
	{
		m = n = ROW-1;
		//�ƶ�
		while (m > 0 && n > 0)
		{
			if (arr[m][i] == 0)
			{
				for (j = m; j > 0; j--)
					arr[j][i] = arr[j - 1][i];
				arr[j][i] = 0;
				n--;
			}
			else
				m--;
		}
		//�ϲ�
		for (j = ROW-1; j > 0; j--)
		{
			if (arr[j][i] == arr[j - 1][i] && arr[j][i] != 0)
			{
				arr[j][i] *= 2;
				arr[j - 1][i] = 0;
			}
		}
		//���ƶ�
		m = n = ROW - 1;
		while (m > 0 && n > 0)
		{
			if (arr[m][i] == 0)
			{
				for (j = m; j > 0; j--)
					arr[j][i] = arr[j - 1][i];
				arr[j][i] = 0;
				n--;
			}
			else
				m--;
		}
	}
}

//���ƶ�
void left(int arr[4][4])
{
	int i = 0, j = 0, m = 0, n = 0;
	for (i = 0; i < ROW; i++)
	{
		m = n = 0;
		//�ƶ�
		while (m < COL- 1 && n < COL - 1)
		{
			if (arr[i][m] == 0)
			{
				for (j = m; j < COL - 1; j++)
					arr[i][j] = arr[i][j + 1];
				arr[i][j] = 0;
				n++;
			}
			else
				m++;
		}
		//�ϲ�
		for (j = 0; j < COL; j++)
		{
			if (arr[i][j] == arr[i][j + 1] && arr[i][j] != 0)
			{
				arr[i][j] *= 2;
				arr[i][j + 1] = 0;
			}
		}
		//���ƶ�
		m = n = 0;
		while (m < COL - 1 && n < COL - 1)
		{
			if (arr[i][m] == 0)
			{
				for (j = m; j < COL - 1; j++)
					arr[i][j] = arr[i][j + 1];
				arr[i][j] = 0;
				n++;
			}
			else
				m++;
		}
	}
}

//���ƶ�
void right(int arr[4][4])
{
	int i = 0, j = 0, m = 0, n = 0;
	for (i = 0; i < ROW; i++)
	{
		m = n = COL-1;
		//�ƶ�
		while (m > 0 && n > 0)
		{
			if (arr[i][m] == 0)
			{
				for (j = m; j > 0; j--)
					arr[i][j] = arr[i][j - 1];
				arr[i][j] = 0;
				n--;
			}
			else
				m--;
		}
		//�ϲ�
		for (j = COL - 1; j > 0; j--)
		{
			if (arr[i][j] == arr[i][j - 1] && arr[i][j] != 0)
			{
				arr[i][j] *= 2;
				arr[i][j - 1] = 0;
			}
		}
		//���ƶ�
		m = n = COL - 1;
		while (m > 0 && n > 0)
		{
			if (arr[i][m] == 0)
			{
				for (j = m; j > 0; j--)
					arr[i][j] = arr[i][j - 1];
				arr[i][j] = 0;
				n--;
			}
			else
				m--;
		}
	}
}

//����������
void put_num(int arr[4][4])
{
	srand((unsigned int)time(NULL));
	int x = rand() % 4, y = rand() % 4;
	while (arr[x][y] != 0)
	{
		x = rand() % 4;
		y = rand() % 4;
	}
	int z = rand() & 10;
	if (z < 9)
		arr[x][y] = 2;
	else
		arr[x][y] = 4;
}

//�ж�ʤ��
//������2048ʱʤ���������������޷�����ʱʧ��
//����1����ʤ��������0��������
int win(int arr[4][4])
{
	int i = 0, j = 0;
	for (i = 0; i < ROW; i++)
	{
		for (j = 0; j < COL; j++)
			if (arr[i][j] >= 2048)
				return 1;
	}
	return 0;
}

//�ж��Ƿ�ʧ��
//�����������޷�����ʱʧ��
//����1����ʧ�ܣ�����0��������
int fail(int arr[4][4])
{
	int i = 0, j = 0;
	for (i = 0; i < ROW; i++)
	{
		for (j = 0; j < COL; j++)
		{
			if (arr[i][j] == 0)
				return 0;
			if (i > 0)
				if (arr[i - 1][j] == arr[i][j])
					return 0;
			if (j > 0)
				if (arr[i][j - 1] == arr[i][j])
					return 0;
		}
	}
	return 1;
}

//��Ϸ����
void game2048()
{
	int board[4][4] = { 0 };
	get_num(board);
	PrintBoard(board);
	while(1)
	{
		Move(board);
		char c = 0;
		c = getchar();
		if (win(board))
		{
			printf("��ϲͨ��\n");
			break;
		}
		if (fail(board))
		{
			printf("��Ϸʧ�ܣ�̫����\n");
			break;
		}
		put_num(board);
		PrintBoard(board);
	}
}